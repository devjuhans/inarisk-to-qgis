import os
from qgis.PyQt.QtWidgets import (QDialog, QVBoxLayout, QHBoxLayout, QGroupBox, 
                                 QRadioButton, QComboBox, QPushButton, QFileDialog, 
                                 QLabel, QCheckBox, QDialogButtonBox, QLineEdit, QFormLayout,
                                 QSplitter, QTabWidget, QScrollArea, QTextEdit, QTextBrowser,
                                 QProgressBar, QWidget, QSizePolicy, QListWidget, QListWidgetItem)
from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtGui import QIcon, QIntValidator
from qgis.core import QgsProject, QgsMapLayerType
from .i18n_manager import tr, I18nManager

class ModeSelectionDialog(QDialog):
    def __init__(self, parent=None):
        super(ModeSelectionDialog, self).__init__(parent)
        self.setWindowTitle('InaRISK to QGIS - Select Mode')
        self.resize(300, 100)
        
        layout = QVBoxLayout(self)
        self.btn_server = QPushButton(tr("Download from InaRISK Server (GeoServer)"))
        self.btn_local = QPushButton(tr("Process Local Zip Files"))
        
        layout.addWidget(self.btn_server)
        layout.addWidget(self.btn_local)
        
        self.mode = None
        self.btn_server.clicked.connect(self.select_server)
        self.btn_local.clicked.connect(self.select_local)
        
    def select_server(self):
        self.mode = 'server'
        self.accept()

class InaRiskToQgisDialog(QDialog):
    def __init__(self, iface, parent=None):
        super(InaRiskToQgisDialog, self).__init__(parent or iface.mainWindow())
        self.iface = iface
        
        self.i18n = I18nManager.get_instance()

        self.setWindowTitle(tr('InaRISK to QGIS'))
        self.setWindowIcon(QIcon(os.path.join(os.path.dirname(__file__), 'earth.svg')))
        self.resize(850, 600)
        
        main_layout = QVBoxLayout(self)

        self.splitter = QSplitter(Qt.Orientation.Horizontal)
        
        # --- LEFT PANE (Tabs) ---
        self.tabs = QTabWidget()
        
        # 1. Parameters Tab
        self.tab_params = QWidget()
        params_layout = QVBoxLayout(self.tab_params)
        
        # Top bar with language selector
        lang_layout = QHBoxLayout()
        lang_layout.addStretch()
        self.cmb_lang = QComboBox()
        self.cmb_lang.addItems(["English", "Bahasa Indonesia"])
        if self.i18n.current_lang == "Bahasa Indonesia":
            self.cmb_lang.setCurrentText("Bahasa Indonesia")
        else:
            self.cmb_lang.setCurrentText("English")
        self.cmb_lang.currentIndexChanged.connect(self.change_language)
        
        self.lbl_language = QLabel(tr("Language:"))
        lang_layout.addWidget(self.lbl_language)
        lang_layout.addWidget(self.cmb_lang)
        params_layout.addLayout(lang_layout)
        
        self.scroll = QScrollArea()
        self.scroll.setWidgetResizable(True)
        self.scroll.setFrameShape(QScrollArea.Shape.NoFrame)
        self.scroll_content = QWidget()
        self.scroll_layout = QVBoxLayout(self.scroll_content)
        
        # Source Settings
        self.server_widget = QGroupBox(tr("Index Options"))
        server_form = QFormLayout(self.server_widget)
        server_form.setVerticalSpacing(4)
        self.cmb_server_index = QComboBox()
        self.cmb_server_index.addItem(tr("Hazard"), "Bahaya")
        self.cmb_server_index.addItem(tr("Risk"), "Risiko")
        self.cmb_server_index.addItem(tr("Vulnerability"), "Kerentanan")
        self.list_server_disaster = QListWidget()
        self.list_server_disaster.setMinimumHeight(135)
        self.list_server_disaster.setStyleSheet("""
            QListWidget {
                padding: 1px;
            }
            QListWidget::item {
                padding: 1px 2px;
                margin: 0px;
            }
        """)
        
        self.chk_all_disasters = QCheckBox(tr("Download all types"))
        self.chk_all_disasters.stateChanged.connect(self.toggle_all_disasters)
        
        self.cmb_server_index.currentIndexChanged.connect(self.update_server_disasters)
        self.update_server_disasters()
        
        self.lbl_index_type = QLabel(tr("Index Type:"))
        self.lbl_disaster = QLabel(tr("Disaster:"))
        
        server_form.addRow(self.lbl_index_type, self.cmb_server_index)
        server_form.addRow(self.lbl_disaster, self.list_server_disaster)
        server_form.addRow("", self.chk_all_disasters)
        self.scroll_layout.addWidget(self.server_widget)

        # Area Selection
        self.area_group = QGroupBox(tr("Area Selection"))
        area_form = QFormLayout(self.area_group)
        area_form.setVerticalSpacing(4)
        
        aoi_layout = QHBoxLayout()
        aoi_layout.setContentsMargins(0, 0, 0, 0)
        self.cmb_aoi = QComboBox()
        self.cmb_aoi.setEditable(True)
        self.cmb_aoi.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        self.refresh_layers()
        
        self.btn_browse_aoi = QPushButton(tr("Browse"))
        self.btn_browse_aoi.clicked.connect(self.browse_aoi)
        
        aoi_layout.addWidget(self.cmb_aoi)
        aoi_layout.addWidget(self.btn_browse_aoi)
        
        self.lbl_area_layer = QLabel(tr("Area Layer:"))
        
        area_form.addRow(self.lbl_area_layer, aoi_layout)
        self.scroll_layout.addWidget(self.area_group)

        # Output Options
        self.out_group = QGroupBox(tr("Output Options"))
        out_layout = QFormLayout()
        out_layout.setVerticalSpacing(4)
        
        self.txt_year = QLineEdit()
        self.txt_year.setPlaceholderText(tr("Optional"))
        self.txt_year.setValidator(QIntValidator(0, 9999, self))
        self.txt_year.setMaxLength(4)
        self.lbl_year = QLabel(tr("Access Year:"))
        out_layout.addRow(self.lbl_year, self.txt_year)
        
        out_dir_layout = QHBoxLayout()
        out_dir_layout.setContentsMargins(0, 0, 0, 0)
        self.txt_out_dir = QLineEdit()
        self.txt_out_dir.setPlaceholderText(tr("[Create temporary layer]"))
        self.btn_browse_out = QPushButton(tr("Browse"))
        self.btn_browse_out.clicked.connect(self.browse_out_dir)
        out_dir_layout.addWidget(self.txt_out_dir)
        out_dir_layout.addWidget(self.btn_browse_out)
        
        self.lbl_save_folder = QLabel(tr("Save Folder:"))
        out_layout.addRow(self.lbl_save_folder, out_dir_layout)
        
        self.cmb_out_type = QComboBox()
        self.cmb_out_type.addItems([tr("Output as Raster"), tr("Output as Vector (Polygons)")])
        
        self.lbl_out_type = QLabel(tr("Output Type:"))
        out_layout.addRow(self.lbl_out_type, self.cmb_out_type)
        
        self.cmb_format = QComboBox()
        self.lbl_format = QLabel(tr("Format:"))
        out_layout.addRow(self.lbl_format, self.cmb_format)
        
        self.cmb_classify = QComboBox()
        self.cmb_classify.addItems([tr("Classify"), tr("Do Not Classify")])
        self.lbl_classify = QLabel(tr("Classification:"))
        out_layout.addRow(self.lbl_classify, self.cmb_classify)
        
        self.chk_symbolize = QCheckBox(tr("Adjust Gradual Symbology"))
        self.chk_symbolize.setToolTip(tr("Apply thematic colors: Green (Low), Yellow (Medium), Red (High)."))
        self.chk_symbolize.setChecked(True)
        out_layout.addRow("", self.chk_symbolize)
        
        self.cmb_classify.currentIndexChanged.connect(self.toggle_classify_options)
        self.toggle_classify_options()
        
        self.out_group.setLayout(out_layout)
        self.scroll_layout.addWidget(self.out_group)
        
        self.scroll_layout.addStretch() # Push everything up
        self.scroll.setWidget(self.scroll_content)
        params_layout.addWidget(self.scroll)
        self.tabs.addTab(self.tab_params, tr("Parameters"))

        # 2. Log Tab
        self.tab_log = QWidget()
        log_layout = QVBoxLayout(self.tab_log)
        self.txt_log = QTextEdit()
        self.txt_log.setReadOnly(True)
        log_layout.addWidget(self.txt_log)
        self.tabs.addTab(self.tab_log, tr("Log"))
        
        self.splitter.addWidget(self.tabs)

        # --- RIGHT PANE (Help Browser) ---
        self.help_browser = QTextBrowser()
        self.help_browser.setHtml(self.get_help_html())
        self.splitter.addWidget(self.help_browser)
        
        self.splitter.setSizes([550, 300])
        main_layout.addWidget(self.splitter)

        # --- BOTTOM BAR ---
        self.progress_bar = QProgressBar()
        self.progress_bar.setValue(0)
        self.progress_bar.setTextVisible(True)
        main_layout.addWidget(self.progress_bar)
        
        self.buttonBox = QDialogButtonBox()
        self.btn_run = QPushButton(tr("Run"))
        self.btn_close = QPushButton(tr("Close"))
        self.buttonBox.addButton(self.btn_run, QDialogButtonBox.ButtonRole.ActionRole)
        self.buttonBox.addButton(self.btn_close, QDialogButtonBox.ButtonRole.RejectRole)
        
        self.btn_run.clicked.connect(self.run_process)
        self.btn_close.clicked.connect(self.reject)
        main_layout.addWidget(self.buttonBox)
        
        # Connect format toggle
        self.cmb_out_type.currentIndexChanged.connect(self.toggle_format_options)
        self.toggle_format_options() # Initial setup
        
    def change_language(self, index):
        lang = self.cmb_lang.currentText()
        self.i18n.set_language(lang)
        self.retranslate_ui()

    def retranslate_ui(self):
        self.setWindowTitle(tr('InaRISK to QGIS'))
        self.lbl_language.setText(tr("Language:"))
        self.server_widget.setTitle(tr("Index Options"))
        
        # update index types
        idx_idx = self.cmb_server_index.currentIndex()
        self.cmb_server_index.blockSignals(True)
        self.cmb_server_index.setItemText(0, tr("Hazard"))
        self.cmb_server_index.setItemText(1, tr("Risk"))
        self.cmb_server_index.setItemText(2, tr("Vulnerability"))
        self.cmb_server_index.blockSignals(False)
        
        # save selected disaster
        checked_data = []
        for i in range(self.list_server_disaster.count()):
            item = self.list_server_disaster.item(i)
            if item.checkState() == Qt.CheckState.Checked:
                checked_data.append(item.data(Qt.ItemDataRole.UserRole))
                
        self.update_server_disasters()
        
        for i in range(self.list_server_disaster.count()):
            item = self.list_server_disaster.item(i)
            if item.data(Qt.ItemDataRole.UserRole) in checked_data:
                item.setCheckState(Qt.CheckState.Checked)
        
        self.chk_all_disasters.setText(tr("Download all types"))
        self.lbl_index_type.setText(tr("Index Type:"))
        self.lbl_disaster.setText(tr("Disaster:"))
        self.area_group.setTitle(tr("Area Selection"))
        self.btn_browse_aoi.setText(tr("Browse"))
        self.lbl_area_layer.setText(tr("Area Layer:"))
        self.out_group.setTitle(tr("Output Options"))
        
        if self.txt_out_dir.text() == "":
            self.txt_out_dir.setPlaceholderText(tr("[Create temporary layer]"))
        
        self.btn_browse_out.setText(tr("Browse"))
        self.lbl_save_folder.setText(tr("Save Folder:"))
        
        # Update combo box items
        self.cmb_out_type.blockSignals(True)
        out_type_idx = self.cmb_out_type.currentIndex()
        self.cmb_out_type.setItemText(0, tr("Output as Raster"))
        self.cmb_out_type.setItemText(1, tr("Output as Vector (Polygons)"))
        self.cmb_out_type.blockSignals(False)
        
        self.lbl_out_type.setText(tr("Output Type:"))
        self.lbl_format.setText(tr("Format:"))
        
        cur_classify_idx = self.cmb_classify.currentIndex()
        self.cmb_classify.blockSignals(True)
        self.cmb_classify.setItemText(0, tr("Classify"))
        self.cmb_classify.setItemText(1, tr("Do Not Classify"))
        self.cmb_classify.setCurrentIndex(cur_classify_idx)
        self.cmb_classify.blockSignals(False)
        
        self.lbl_classify.setText(tr("Classification:"))
        self.chk_symbolize.setText(tr("Adjust Gradual Symbology"))
        self.chk_symbolize.setToolTip(tr("Apply thematic colors: Green (Low), Yellow (Medium), Red (High)."))
        self.lbl_year.setText(tr("Access Year:"))
        self.txt_year.setPlaceholderText(tr("Optional"))
        self.toggle_classify_options()
        
        self.tabs.setTabText(0, tr("Parameters"))
        self.tabs.setTabText(1, tr("Log"))
        
        self.help_browser.setHtml(self.get_help_html())
        
        self.btn_run.setText(tr("Run"))
        self.btn_close.setText(tr("Close"))

    def get_help_html(self):
        return f"""
        <html>
        <head>
            <style>
                body {{ font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Arial, sans-serif; font-size: 11px; margin: 8px; color: #2c3e50; line-height: 110%; }}
                h2 {{ color: #2c3e50; font-size: 13px; margin: 0 0 4px 0; font-weight: bold; line-height: 110%; }}
                h3 {{ color: #34495e; font-size: 11px; margin: 8px 0 2px 0; font-weight: bold; line-height: 110%; }}
                p {{ margin: 0 0 5px 0; line-height: 110%; text-align: left; }}
                .footer-box {{ background-color: #f8f9fa; border-left: 3px solid #FE8038; padding: 5px 8px; margin-top: 8px; font-size: 10px; color: #555; line-height: 110%; }}
            </style>
        </head>
        <body>
            <h2>{tr('InaRISK to QGIS')}</h2>
            <p>{tr('Download and process InaRISK disaster layers directly from BNPB servers.')}</p>
            
            <h3>{tr('User Guide')}</h3>
            <p>{tr('Select the index type and disaster layers, then specify an Area Layer (AOI) to define the spatial boundary.')}</p>
            <p>{tr('Choose Raster (.tif) or Vector Polygons (.shp, .gpkg, .geojson, .kml). Classification categorizes continuous index values into three BNPB tiers: Low (0 - 0.333), Medium (0.333 - 0.667), and High (0.667 - 1.0) with optional gradual symbology. Leave the save folder blank to generate temporary layers.')}</p>
            
            <h3>{tr('Vector Attributes')}</h3>
            <p>{tr("Vector outputs include 'Kelas' (index category), 'Value' (index range), and 'Source' (attribution with optional access year).")}</p>

            <div class="footer-box">
                <b>{tr('Notice:')}</b> {tr('Requires an active internet connection to access BNPB servers.')}<br>
                {tr('Contact:')} <a href="mailto:juhans@karpo.work">juhans@karpo.work</a>
            </div>
        </body>
        </html>
        """

    def run_process(self):
        from .core_logic import InaRiskProcessor
        self.btn_run.setEnabled(False)
        self.tabs.setCurrentIndex(1) # Switch to Log tab
        self.progress_bar.setValue(0)
        self.txt_log.clear()
        
        processor = InaRiskProcessor(self, self.iface)
        processor.process()
        
        self.btn_run.setEnabled(True)

    def toggle_format_options(self):
        is_vector = (self.cmb_out_type.currentIndex() == 1)
        self.cmb_format.clear()
        if is_vector:
            self.cmb_format.addItems(['.shp', '.gpkg', '.geojson', '.kml'])
        else:
            self.cmb_format.addItems(['.tif'])

    def toggle_classify_options(self):
        is_classified = (self.cmb_classify.currentIndex() == 0)
        self.chk_symbolize.setEnabled(is_classified)
        if not is_classified:
            self.chk_symbolize.setChecked(False)
        else:
            self.chk_symbolize.setChecked(True)

    def update_server_disasters(self):
        index_type = self.cmb_server_index.currentData()
        self.list_server_disaster.clear()
        
        if index_type == 'Bahaya':
            disasters = [
                ('Flood', 'Banjir'), ('Flash Flood', 'Banjir Bandang'), ('Extreme Weather', 'Cuaca Ekstrim'), 
                ('Extreme Wave and Abrasion', 'Gelombang Ekstrim dan Abrasi'), ('Earthquake', 'Gempa Bumi'), 
                ('Volcano', 'Gunung Api'), ('Drought', 'Kekeringan'), ('Liquefaction', 'Likuefaksi'), 
                ('Forest and Land Fire', 'Karhutla'), ('Landslide', 'Tanah Longsor'), ('Tsunami', 'Tsunami'),
                ('Multi', 'Multi')
            ]
        elif index_type == 'Kerentanan':
            disasters = [
                ('Flood', 'Banjir'), ('Flash Flood', 'Banjir Bandang'), ('Extreme Weather', 'Cuaca Ekstrim'), 
                ('Extreme Wave and Abrasion', 'Gelombang Ekstrim dan Abrasi'), ('Earthquake', 'Gempa Bumi'), 
                ('Volcano', 'Gunung Api'), ('Drought', 'Kekeringan'), ('Liquefaction', 'Likuefaksi'), 
                ('Forest and Land Fire', 'Karhutla'), ('Landslide', 'Tanah Longsor'), ('Tsunami', 'Tsunami'),
                ('Multi', 'Multi')
            ]
        elif index_type == 'Risiko':
            disasters = [
                ('Flood', 'Banjir'), ('Flash Flood', 'Banjir Bandang'), ('Extreme Weather', 'Cuaca Ekstrim'), 
                ('Extreme Wave and Abrasion', 'Gelombang Ekstrim dan Abrasi'), ('Earthquake', 'Gempa Bumi'), 
                ('Volcano', 'Gunung Api'), ('Drought', 'Kekeringan'), ('Liquefaction', 'Likuefaksi'), 
                ('Forest and Land Fire', 'Karhutla'), ('Landslide', 'Tanah Longsor'), ('Tsunami', 'Tsunami'),
                ('Multi', 'Multi')
            ]
        else:
            disasters = []
            
        for eng, ind in disasters:
            item = QListWidgetItem(tr(eng))
            item.setData(Qt.ItemDataRole.UserRole, ind)
            item.setFlags(item.flags() | Qt.ItemFlag.ItemIsUserCheckable)
            item.setCheckState(Qt.CheckState.Unchecked)
            self.list_server_disaster.addItem(item)
            
        if hasattr(self, 'chk_all_disasters') and self.chk_all_disasters.isChecked():
            for i in range(self.list_server_disaster.count()):
                self.list_server_disaster.item(i).setCheckState(Qt.CheckState.Checked)

    def browse_out_dir(self):
        directory = QFileDialog.getExistingDirectory(self, tr("Select Output Folder"))
        if directory:
            self.txt_out_dir.setText(directory)

    def browse_aoi(self):
        file_path, _ = QFileDialog.getOpenFileName(self, tr("Select AOI Vector File"), "", tr("Vector files (*.shp *.gpkg *.geojson *.kml)"))
        if file_path:
            self.cmb_aoi.setCurrentText(file_path)

    def toggle_all_disasters(self):
        if hasattr(self, 'chk_all_disasters'):
            is_checked = self.chk_all_disasters.isChecked()
            for i in range(self.list_server_disaster.count()):
                item = self.list_server_disaster.item(i)
                item.setCheckState(Qt.CheckState.Checked if is_checked else Qt.CheckState.Unchecked)
            self.list_server_disaster.setEnabled(not is_checked)

    def refresh_layers(self):
        self.cmb_aoi.clear()
        layers = QgsProject.instance().mapLayers().values()
        for layer in layers:
            if layer.type() == QgsMapLayerType.VectorLayer:
                self.cmb_aoi.addItem(layer.name(), layer.id())
